# Whisper_Waltz

### Description
Since arriving here, creepy music and voices have become noticeable. The atmosphere is unsettling, with every shadow suggesting secrets are nearby. I've found this evidence. Can you help me piece together these clues and uncover the dark secrets hidden within? 

Flag Format: inctfj{....}

### Author
**```__m1m1__```**