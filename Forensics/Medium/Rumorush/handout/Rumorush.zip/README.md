# Rumorush

### Description
It appears that there's a conversation of the person spreading rumors about the mansion, captured in fragments. However, the text is difficult to read and seems disjointed. Help reveal the hidden message within this conversation.

Flag Format: inctfj{....}

### Author

**```__m1m1__```**