# Haunt_hunt

### Description
It seems obscured with hidden secrets. Can you uncover anything within this strange evidence?

Flag Format: inctfj{....}


### Author
**```__m1m1__```**