# Eerific

### Description

When entered the mansion, found a peculiar picture hanging on the wall.
Can you find the secrets obscured within its frame?

Flag Format: inctfj{....}

### Author

**```__m1m1__```**