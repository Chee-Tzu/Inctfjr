# Commands to setup docker

+ docker build . -t batcomputer_breach
+ docker run -p 1338:1338 batcomputer_breach
+ nc localhost 1338
