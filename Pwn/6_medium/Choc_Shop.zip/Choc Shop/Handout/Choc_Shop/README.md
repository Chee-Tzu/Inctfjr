# Commands to setup docker

+ docker build . -t choc_shop
+ docker run -p 1338:1338 choc_shop
+ nc localhost 1338
