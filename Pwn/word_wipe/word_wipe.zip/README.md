# Secretive Word Game

### Challenge Description

I've dived headfirst into this word game, but the instructions are about as clear as a whispered secret in a hurricane!  Can you lend a hand and unravel this cryptic puzzle with me?

**Challenge File**:
+ [Primary Link]()
+ [Mirror Link]()

**MD5 Hash**: 756dcfed8b64caf45849bd47d1ba13ec

### Short Writeup

+  Use the negative indexing bug to get leaks
+  Use the same bug to create a ROP chain to call system

### Flag

inctfj{y0u_found_th3_s3qu3nce_t0_v1ct0ry_182761337}

### Author

**tourpran**