# Challenge Name

Leaky Format

### Challenge Description

I wrote a code to add your name in a movie quote! But, my friend tells me that there's an error in my code, but I can't really find it! Can you help me find the bug?

**Challenge File**:
+ [Primary Link](https://drive.google.com/file/d/1_pM-UXu2QKDp9GMTR1dyCx0CNJrmeW1z/view?usp=sharing)
+ [Mirror Link](https://mega.nz/file/lOVmXTxS#P1y7JPsTeKGC8kZSidQ8_Ppe30CHNLEGe3q32Vmy-EU)

**MD5 Hash**: 1b09a4d5a13d48268b136cd473241ab9

### Short Writeup

+  Abuse Format String Bug, to leak the flag off the stack.

### Flag

inctfj{7h3r3_1s_n0th1ng_fr3e_exc3pt_th3_gr4c3_of_g0d_89hdvsc98}

### Author

**SkyLance**