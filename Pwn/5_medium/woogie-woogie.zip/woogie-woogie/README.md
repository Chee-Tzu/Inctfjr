# Challenge Name

Woogie-Woogie

### Challenge Description

Your brother Schneizel refuses to share the codes for the fleija warheads, maybe beating him in a game of chess will make him talk?

**Challenge File**:
+ [Primary Link](https://drive.google.com/file/d/1e0ULSfO3dx5vezuexq1VScyRX6ZZk8lB/view?usp=sharing)
+ [Mirror Link](https://mega.nz/file/Ia8QESiC#GZykFk802QCO6rrM-FTUit6ncaWQAv53T24MNY0VBTc)

**MD5 Hash**: ea621f1640a9693ed8f9341a816ed783

### Short Writeup

+  Using a technique called ret2plt to get a libc leak, and then calling the libc symbol system, with a libc pointer to "/bin/sh" as argument, using a pop_rdi gadget.

### Flag

inctfj{y0u_c4n7_ch4nge_7he_w0rld_w17h0ut_g3771ng_y0ur_h4nd5_d1r7y_9gdf8hkl}

### Author

**SkyLance**