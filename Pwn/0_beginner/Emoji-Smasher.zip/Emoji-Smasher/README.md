# Emoji Smasher

### Challenge Description

We made an emoji smasher. Can you smash it?

**Challenge File**:
+ [Primary Link](https://drive.google.com/file/d/1iM8X3bWz-9EZdBBR46tBu_KQiH53G46u/view?usp=sharing)
+ [Mirror Link](https://1drv.ms/u/s!AmwNFYE660J7gnrIMFcY0_HuY8bL?e=gUcliG)

**MD5 Hash**: 6d2b45ce322c0d96149dcf799a8488c9

### Short Writeup

+  Smash the stack by spamming characters until you overflow the comparison variable.

### Flag

inctfj{sm45h_0r_p4ss??_fh6tg767ftgyj867g}

### Author

**HeartStoller, SkyLance**