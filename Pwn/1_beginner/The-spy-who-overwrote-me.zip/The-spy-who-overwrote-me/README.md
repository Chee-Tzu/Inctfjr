# The spy who overwrote me

### Challenge Description

Help 007 complete his mission. You are his only hope.

**Challenge File**:
+ [Primary Link](https://drive.google.com/file/d/1_HALQWO7yDV_Hj4Js672cyoLOFxWgfnY/view?usp=sharing)
+ [Mirror Link](https://1drv.ms/u/s!AmwNFYE660J7gndEX_m7tiOgsmaY?e=5qFPWe)

**MD5 Hash**: 9dc689e8ea2e924353fd374aa55bbe24

### Short Writeup

+  The challenge is just a simple variable overwrite. If the condition checks gets bypassed by overwriting the variable win function gets triggered and prints the flag.

### Flag

inctfj{drN0_1s_4_m3mb3r_0f_sp3c7r3}

### Author

**HeartStoller**