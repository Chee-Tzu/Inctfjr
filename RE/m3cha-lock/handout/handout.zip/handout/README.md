# M3CHA Lock 

### Description
Can you beat my super safe lock?

### Resources
- [How can I figure out what this file is doing?](https://infosecwriteups.com/reverse-engineering-a-binary-with-ida-free-346cab16be9f)
- [What is XOR?](https://bluegoatcyber.com/blog/how-is-xor-used-in-encryption/)

