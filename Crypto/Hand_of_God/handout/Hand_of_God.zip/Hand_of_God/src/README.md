Contains Dockerfile and Challenge.py

